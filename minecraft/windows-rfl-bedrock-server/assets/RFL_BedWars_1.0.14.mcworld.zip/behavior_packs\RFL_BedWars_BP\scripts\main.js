import { system } from "@minecraft/server";
import { BedWarsEngine } from "./core/engine.js";

const engine = new BedWarsEngine();
system.run(() => engine.initialize());
